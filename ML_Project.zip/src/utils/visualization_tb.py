# data manipulation
import numpy as np
import pandas as pd 

# visualization
import seaborn as sns
import matplotlib.pyplot as plt

# route files
import os
import sys


# Represent all different notes in one song-------------------
# ---------------------in streamlit let user choose the song, o hacer las gráficas en streamlit para que sean interactivas

def plot_one_song(number):
    """
    Plot all different notes and rests contained in one song
    """
    clean_column = df["Notes"][number]
    contador = 0
    while contador <= len(clean_column):
        contador +=1
        for elem in clean_column:
            if elem.count(".") >= 1 or elem == "NULL" or elem.isdigit() == True:
                clean_column.remove(elem)

    fig, ax = plt.subplots(figsize=(8, 4))

    piece_title= df["Piece"][number]
    sns.histplot(clean_column, color = "green", label=f"Piece title: {piece_title[2:]}")

    ax.set_xlabel("Notes")
    ax.legend(loc="best")
    plt.xticks(rotation = 90)

    plt.show()